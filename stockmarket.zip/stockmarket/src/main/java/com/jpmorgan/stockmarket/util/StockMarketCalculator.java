package com.jpmorgan.stockmarket.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.jpmorgan.stockmarket.entity.Stock;
import com.jpmorgan.stockmarket.entity.Trade;

public class StockMarketCalculator {
	
	/**Calculates the dividend Based on Stock type**/
	public double getDividendYieldByStockType(Stock stock, double price) {
		double dividend = 0;
		if(null==stock) {
			return dividend;
		}
		switch (stock.getStockType()) {
		case COMMON:
			dividend = (stock.getLastDividend() / price);
			break;
		case PREFERRED:
			dividend = ((stock.getFixedDividend() * stock.getParValue()) / price);
			break;
		default:

		}
		return dividend;
	}
	
	public double getCalculatedPERatio(Stock stock, double price) {
		double peRatioValue=0;
		double dividend = getDividendYieldByStockType(stock, price);
		if(price >0 && dividend >0) {
			return price/dividend;
		}else {
			return peRatioValue;
		}
		
	}
	
	 public static double geometricMean(List<Double> stockPrices) {
	        int stockPricesArrayLength = stockPrices.size();
	        double GM_log = 0.0d;
	        for (int i = 0; i < stockPricesArrayLength; ++i) {
	            GM_log += Math.log(stockPrices.get(i));
	        }
	        return Math.exp(GM_log / stockPricesArrayLength);
	    }

	
	public double getStockPriceByMinutes(Stock stock,int noOfMinutes,List<Trade> tradesList) {
		List<Trade> tradesMatchingCriteria = new ArrayList<Trade>();
		Date timeToCompare = new Date(System.currentTimeMillis()-noOfMinutes*60*1000);
		double totalTradePrice = 0;
		int shareQuantity =0;
		if(null!=tradesList && tradesList.size()>0 && null!=stock ) {
			for(Trade t: tradesList) {
				//consider each trade contains multiple stocks
				for(Stock s: t.getStock()) {
					if((s.getStockSymbol().equals(stock.getStockSymbol()))) {
						if(t.getDate().compareTo(timeToCompare)==0) {
							tradesMatchingCriteria.add(t);
							break;
						}
					}
				}
				totalTradePrice +=t.getPrice()*t.getStock().size();
				shareQuantity += t.getStock().size();
			}
			
		}
		return ((totalTradePrice*shareQuantity)/shareQuantity);
		
	}
}
