package com.jpmorgan.stockmarket.entity;

import com.jpmorgan.stockmarket.constant.StockTypes;

public class Stock {

	private String stockSymbol;
	
	private double lastDividend;
	
	private double fixedDividend;
	
	private double parValue;
	
	private StockTypes StockType;
	
	private double price;
	
	

	/**
	 * @param stockSymbol
	 * @param lastDividend
	 * @param fixedDividend
	 * @param parValue
	 * @param stockType
	 * @param price
	 */
	public Stock(String stockSymbol,StockTypes stockType, double lastDividend, double fixedDividend, double parValue) {
		super();
		this.stockSymbol = stockSymbol;
		this.lastDividend = lastDividend;
		this.fixedDividend = fixedDividend;
		this.parValue = parValue;
		StockType = stockType;
	}

	/**
	 * 
	 */
	public Stock() {
		super();
	}

	/**
	 * @return the stockSymbol
	 */
	public String getStockSymbol() {
		return stockSymbol;
	}

	/**
	 * @param stockSymbol the stockSymbol to set
	 */
	public void setStockSymbol(String stockSymbol) {
		this.stockSymbol = stockSymbol;
	}

	/**
	 * @return the lastDividend
	 */
	public double getLastDividend() {
		return lastDividend;
	}

	/**
	 * @param lastDividend the lastDividend to set
	 */
	public void setLastDividend(double lastDividend) {
		this.lastDividend = lastDividend;
	}

	/**
	 * @return the fixedDividend
	 */
	public double getFixedDividend() {
		return fixedDividend;
	}

	/**
	 * @param fixedDividend the fixedDividend to set
	 */
	public void setFixedDividend(double fixedDividend) {
		this.fixedDividend = fixedDividend;
	}

	/**
	 * @return the perValue
	 */
	public double getParValue() {
		return parValue;
	}

	/**
	 * @param perValue the perValue to set
	 */
	public void setParValue(double parValue) {
		this.parValue = parValue;
	}

	/**
	 * @return the stockType
	 */
	public StockTypes getStockType() {
		return StockType;
	}

	/**
	 * @param stockType the stockType to set
	 */
	public void setStockType(StockTypes stockType) {
		StockType = stockType;
	}

	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}

	/**
	 * @param price the price to set
	 */
	public void setPrice(double price) {
		this.price = price;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Stock [stockSymbol=" + stockSymbol + ", lastDividend=" + lastDividend + ", fixedDividend="
				+ fixedDividend + ", parValue=" + parValue + ", StockType=" + StockType + ", price=" + price + "]";
	}
	
	
	
}
