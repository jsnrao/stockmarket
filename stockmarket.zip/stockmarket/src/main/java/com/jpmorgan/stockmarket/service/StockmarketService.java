package com.jpmorgan.stockmarket.service;

import java.util.Date;

interface StockmarketService {

	double getCalculatedDividendYield(String stockSymbol, double price);

	double getCalculatedPERatio(String stockSymbol, double price);

	boolean registerRecord(Date date, int quantity, String tradeType, double price);

	double getStockPriceByMinutes(String stockSymbol, int noOfMinutes);
	
	double getGeometricMeanCalculatedValue();

	

}
