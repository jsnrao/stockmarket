package com.jpmorgan.stockmarket.entity;

import java.util.Date;
import java.util.List;

import com.jpmorgan.stockmarket.constant.TradeType;

public class Trade {

	private Date date;
	private int quantity;
	private TradeType tradeType;
	private double price;
	private List<Stock> stock;
	
	/**
	 * @param date
	 * @param quantity
	 * @param tradeType
	 * @param price
	 */
	public Trade(Date date, int quantity, TradeType tradeType, double price) {
		super();
		this.date = date;
		this.quantity = quantity;
		this.tradeType = tradeType;
		this.price = price;
	}
	/**
	 * @return the date
	 */
	public Date getDate() {
		return date;
	}
	/**
	 * @param date the date to set
	 */
	public void setDate(Date date) {
		this.date = date;
	}
	/**
	 * @return the quantity
	 */
	public int getQuantity() {
		return quantity;
	}
	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	/**
	 * @return the tradeType
	 */
	public TradeType getTradeType() {
		return tradeType;
	}
	/**
	 * @param tradeType the tradeType to set
	 */
	public void setTradeType(TradeType tradeType) {
		this.tradeType = tradeType;
	}
	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(double price) {
		this.price = price;
	}
	/**
	 * @return the stock
	 */
	public List<Stock> getStock() {
		return stock;
	}
	/**
	 * @param stock the stock to set
	 */
	public void setStock(List<Stock> stock) {
		this.stock = stock;
	}

	
	
	
}


