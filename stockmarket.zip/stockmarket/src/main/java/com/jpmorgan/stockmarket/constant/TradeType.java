package com.jpmorgan.stockmarket.constant;

public enum TradeType {

	BUY,SELL;
}
