package com.jpmorgan.stockmarket.constant;

public enum StockTypes {

	COMMON, PREFERRED
}
