package com.jpmorgan.stockmarket.repository;

import java.util.Collection;
import java.util.List;

import com.jpmorgan.stockmarket.entity.Stock;
import com.jpmorgan.stockmarket.entity.Trade;

public interface StockMarketRepository {
	
	Stock getStockBasedOnStockSymbol(String symbol);
	boolean saveTrade(Trade trade);
	Trade fetchTradesBasedOnTradeType(String tradeType);
	Trade fetchTradesBasedOnTimeandType(String tradeType,int minutes);
	List<Trade> getTradesList();
	Collection<Stock> getAllStocks();

}
