package com.jpmorgan.stockmarket.service;

public class StockPredicate {

}
