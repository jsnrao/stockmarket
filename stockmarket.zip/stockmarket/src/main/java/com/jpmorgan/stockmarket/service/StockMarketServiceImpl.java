package com.jpmorgan.stockmarket.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cglib.core.CollectionUtils;

import com.jpmorgan.stockmarket.constant.TradeType;
import com.jpmorgan.stockmarket.entity.Stock;
import com.jpmorgan.stockmarket.entity.Trade;
import com.jpmorgan.stockmarket.repository.StockMarketRepository;
import com.jpmorgan.stockmarket.util.StockMarketCalculator;

public class StockMarketServiceImpl implements StockmarketService {

	@Autowired
	private StockMarketRepository stockMarketRepository;

	@Autowired
	private StockMarketCalculator stockMarketCalculator;

	private Calendar dateFilter = Calendar.getInstance();

	@Override
	public double getCalculatedDividendYield(String stockSymbol, double price) {

		return stockMarketCalculator
				.getDividendYieldByStockType(stockMarketRepository.getStockBasedOnStockSymbol(stockSymbol), price);
	}

	@Override
	public double getCalculatedPERatio(String stockSymbol, double price) {
		return stockMarketCalculator.getCalculatedPERatio(stockMarketRepository.getStockBasedOnStockSymbol(stockSymbol),
				price);
	}

	@Override
	public boolean registerRecord(Date date, int quantity, String tradeType, double price) {
		Trade trade = new Trade(date, quantity, TradeType.valueOf(tradeType), price);

		return stockMarketRepository.saveTrade(trade);
	}

	@Override
	public double getStockPriceByMinutes(String stockSymbol, int noOfMinutes) {
		double stockPrice = 0;
		if (null != stockSymbol) {
			Stock stock = stockMarketRepository.getStockBasedOnStockSymbol(stockSymbol);
			List<Trade> tradesList = stockMarketRepository.getTradesList();
			stockPrice = stockMarketCalculator.getStockPriceByMinutes(stock, noOfMinutes, tradesList);
		}
		return stockPrice;
	}

	@Override
	public double getGeometricMeanCalculatedValue() {
		Collection<Stock> stocksCollection = stockMarketRepository.getAllStocks();
		List<Double> stockPrices = new ArrayList<Double>();
		for (Stock stock : stocksCollection) {
			double stockPrice = getStockPriceByMinutes(stock.getStockSymbol(), 0);
			if (stockPrice > 0) {
				stockPrices.add(stockPrice);
			}
		}
		return StockMarketCalculator.geometricMean(stockPrices);
	}

}
