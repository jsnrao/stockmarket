package com.jpmorgan.stockmarket.repository;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.jpmorgan.stockmarket.entity.Stock;
import com.jpmorgan.stockmarket.entity.Trade;

public class StockMarketRepositoryImpl implements StockMarketRepository {

	/**
	 * @param stocksMap
	 * @param tradesList
	 */
	public StockMarketRepositoryImpl(Map<String, Stock> stocksMap, List<Trade> tradesList) {
		super();
		stocksMap = new HashMap<String,Stock>();
		tradesList = new ArrayList<Trade>();
	}

	/**
	 * 
	 */
	public StockMarketRepositoryImpl() {
		super();
	}

	private Map<String,Stock> stocksMap;
	private List<Trade> tradesList;
	
	/**
	 * @return the stocksMap
	 */
	public Map<String, Stock> getStocksMap() {
		return stocksMap;
	}

	/**
	 * @param stocksMap the stocksMap to set
	 */
	public void setStocksMap(Map<String, Stock> stocksMap) {
		this.stocksMap = stocksMap;
	}

	/**
	 * @return the tradesList
	 */
	public List<Trade> getTradesList() {
		return tradesList;
	}

	/**
	 * @param tradesList the tradesList to set
	 */
	public void setTradesList(List<Trade> tradesList) {
		this.tradesList = tradesList;
	}

	@Override
	public Stock getStockBasedOnStockSymbol(String symbol) {
		if(stocksMap.containsKey(symbol)){
			return stocksMap.get(symbol);
		}
		return null;
	}

	@Override
	public boolean saveTrade(Trade trade) {
		return tradesList.add(trade);
	}

	@Override
	public Trade fetchTradesBasedOnTradeType(String tradeType) {
		return null;
	}

	@Override
	public Trade fetchTradesBasedOnTimeandType(String tradeType, int minutes) {
		return null;
	}

	@Override
	public Collection<Stock> getAllStocks() {
		return stocksMap.values();
	}
	

}
