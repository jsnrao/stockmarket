package com.jpmorgan.stockmarket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jpmorgan.stockmarket.entity.Stock;

@SpringBootApplication
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
        ApplicationContext context = new ClassPathXmlApplicationContext(
				"stocks-market-values.xml");
        Stock stock = (Stock) context.getBean("stock_pop");
        System.out.println(stock.toString());
    }
}
